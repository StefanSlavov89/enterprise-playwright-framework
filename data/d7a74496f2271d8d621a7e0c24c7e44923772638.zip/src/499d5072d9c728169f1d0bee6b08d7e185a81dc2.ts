import { Page, Locator, expect } from '@playwright/test';

export class LoginPage {
  public readonly page: Page;
  public readonly usernameField: Locator;
  public readonly passwordField: Locator;
  public readonly loginButton: Locator;
  public readonly errorMessage: Locator;
  public readonly logo: Locator;

  constructor(page: Page) {
    this.page = page;
    this.usernameField = page.locator('#user-name');
    this.passwordField = page.locator('#password');
    this.loginButton = page.locator('#login-button');
    this.errorMessage = page.locator('[data-test="error"]');
    this.logo = page.locator('.login_logo');
  }

  async goto() {
    await this.page.goto('/');
  }

  async login(user: string, pass: string) {
    await this.usernameField.fill(user);
    await this.passwordField.fill(pass);
    await this.loginButton.click();
  }

  async expectErrorText(text: string) {
    await expect(this.errorMessage).toHaveText(text);
  }
}
